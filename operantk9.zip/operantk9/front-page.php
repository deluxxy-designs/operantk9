<?php


get_header();?>

<div class="header-section">
	<div class="header-content">
		<h1>TRAIN YOUR DOG TODAY</h1>
		<p>"A better you for a better dog"</p>
		<a class="header-btn" href="#">Book now</a>
	</div>
</div>

<div class="about-section">
 <h2>About</h2>
<img src="http://operantk9.web.dmitcapstone.ca/demo/wp-content/uploads/2019/03/portrait-mobile.png" alt="" width="150" height="150" class="aligncenter size-full wp-image-85" />
 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas semper nec orci aliquet vulputate. Pellentesque dignissim, neque id commodo convallis, ipsum dui suscipit nulla, id convallis justo mi ultricies ante. Sed ante nisl, condimentum nec vehicula eget, vehicula non lacus. In sit amet elementum odio, ac sollicitudin augue. Cras sed mi risus. Nam rutrum urna ut vehicula molestie. Sed finibus sed magna non vulputate. Integer ac consequat ligula. Pellentesque sed ipsum purus. Donec non ipsum vehicula, fringilla ante a, interdum nulla. Nullam mollis erat at risus fermentum ornare. Integer id egestas velit. Cras pharetra molestie lacus, vel rutrum felis fermentum sed.</p>
</div>

<div class="services-container">
 <h2>Services</h2>
 <div class="services">
<img src="http://operantk9.web.dmitcapstone.ca/demo/wp-content/uploads/2019/03/puppy-obed.jpg" alt="" width="500" height="318" class="alignnone size-full wp-image-87" />
  <h3><a href="#">Puppy Obedience<a/></h3>
 </div>
 <div class="services">
<img src="http://operantk9.web.dmitcapstone.ca/demo/wp-content/uploads/2019/03/senior-dog.jpg" alt="" width="500" height="600" class="alignnone size-full wp-image-88" />
  <h3><a href="#">Senior Training<a/></h3>
 </div>
 <div class="services">
<img src="http://operantk9.web.dmitcapstone.ca/demo/wp-content/uploads/2019/03/hvt-program.jpg" alt="" width="500" height="490" class="alignnone size-full wp-image-89" />
  <h3><a href="#">HVT Program<a/></h3>
 </div>
</div>

<div class="join-section">
 <h2>Join the pack today!</h2>
<p>Be able to track your dog's progress and stay updated!</p>
</div>

<div class="sign-up">
<img src="http://operantk9.web.dmitcapstone.ca/demo/wp-content/uploads/2019/03/sign-up.jpg" alt="" width="500" height="333" class="alignnone size-full wp-image-97" />
<a href="#"> Sign Up </a>
</div>

<div class="blog-cast">
<img src="http://operantk9.web.dmitcapstone.ca/demo/wp-content/uploads/2019/03/blog-cast.jpg" alt="" width="500" height="333" class="alignnone size-full wp-image-98" />
<a href="#">Blogcast</a>
</div>

<div class="instagram-gallery">
<h2>Instagram Gallery</h2>
		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>
</div>



<?php get_footer();