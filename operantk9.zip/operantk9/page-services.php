<?php
/*
Template Name: Operantk9-services

*/

get_header();?>
		
	<h1>Our Services</h1>
	
	<div class="services-container">
		<div class="services">
			<h2>Puppy Obedience (8weeks - 1year)</h2>
			<p>Owning a puppy can be rather challenging, or feel like a second full time job; if you've never raised a puppy before. In most cases, behaviour problems are the result of poor training; or, lack there of. The Puppy Obediance Program is an one-on-one program designed to help you, the owner: establish a commication line with your canine companion, build a strong bond, and at the same time make training decisions/recommendations to help avoud future behaviuour problems.</p>
		</div>
		<div class="services">
			<h2>Old Dog – New Trick</h2>
			<p>Owning a puppy can be rather challenging, or feel like a second full time job; if you've never raised a puppy before. In most cases, behaviour problems are the result of poor training; or, lack there of. The Puppy Obediance Program is an one-on-one program designed to help you, the owner: establish a commication line with your canine companion, build a strong bond, and at the same time make training decisions/recommendations to help avoud future behaviuour problems.</p>
		</div>
		<div class="services">
			<h2>HVT Program</h2>
			<p>This program is an all-inclusive program designed to help you all the way though the puppy phases, and help with trouble shooting some of the adolescent stages. All inclusive also means: Operant K9 will provide you with all the necessary equipment for dog ownership: kennel, leash, collar, and “on call” training.</p>
		</div>
	</div>


		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>
</div>



<?php get_footer();